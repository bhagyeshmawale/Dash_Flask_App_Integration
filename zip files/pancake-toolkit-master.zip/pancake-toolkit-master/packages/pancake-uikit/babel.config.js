module.exports = {
  presets: ["@babel/preset-env"],
  plugins: ["styled-components"],
};
