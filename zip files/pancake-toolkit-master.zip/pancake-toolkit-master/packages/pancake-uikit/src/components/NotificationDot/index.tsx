export { default as NotificationDot } from "./NotificationDot";
export type { NotificationDotProps, DotProps } from "./types";
