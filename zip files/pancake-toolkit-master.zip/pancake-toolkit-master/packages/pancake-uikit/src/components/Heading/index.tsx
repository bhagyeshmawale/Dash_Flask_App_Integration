export { default as Heading } from "./Heading";
export type { HeadingProps, Scales as HeadingScales, Tags as HeadingTags } from "./types";
