export interface SpinnerProps {
  size?: number;
}
